# DACATECH Reportes — versión inicial

Frontend React + Vite + Supabase, con interfaz responsive azul/negra.

## Incluye
- Inicio de sesión y registro con Supabase Auth.
- Panel según perfil `admin`, `technician` o `customer`.
- Listado y búsqueda de reportes.
- Creación de reportes con categoría, prioridad, ubicación, descripción y fotografías.
- Evidencias de atención, historial y cambio de estado para personal técnico/administrativo.
- Bucket privado `report-photos` y enlaces firmados para visualizar imágenes.

## Configuración desde un ordenador o entorno de desarrollo
1. Instala Node.js 20 o superior.
2. Descomprime el ZIP y entra en `dacatech-reportes`.
3. Copia `.env.example` como `.env`.
4. Define `VITE_SUPABASE_URL` con `https://dukcvkrlolrhjbcdplse.supabase.co` y `VITE_SUPABASE_PUBLISHABLE_KEY` con la clave pública de tu proyecto.
5. Ejecuta `npm install`, luego `npm run dev`.
6. Antes de publicar, ejecuta `npm run build` y prueba con usuarios separados de cliente, técnico y administrador.

## Importante antes de producción
- La clave `sb_publishable_...` es apta para el frontend; nunca uses `service_role` o claves secretas en el navegador.
- El SQL inicial crea políticas base, pero requiere una auditoría adicional: las reglas para técnicos permiten lectura de reportes de su empresa y asignados; define si eso es lo deseado. Confirma además que la aplicación solo permite cerrar reportes a personal autorizado.
- El rol `admin` se asigna manualmente desde un entorno confiable, como se hizo en la configuración inicial. No permitas que un usuario se asigne a sí mismo `admin`.
- Para producción, revisa el alta de usuarios, límites de archivos, formatos HEIC, notificaciones por correo, registro de auditoría y política de retención.
- La administración avanzada de empresas/usuarios y las invitaciones seguras todavía no están implementadas en esta primera versión.

## Esquema esperado
`companies`, `profiles`, `reports`, `report_photos`, `report_updates`; bucket privado `report-photos`.
